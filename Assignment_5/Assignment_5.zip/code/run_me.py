print("\n\nAnswer 2")
import question_2

print("\n\nAnswer 5")
import question_5

print("\n\nAnswer 8")
import question_8

print("\n\nAnswer 10")
import question_10

print("\n\nAnswer 12")
import question_12

print("\n\nAnswer 13")
import question_13

print("\n\nAnswer 15")
import question_15

print("\n\nAnswer 16")
import question_16
